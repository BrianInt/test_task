CREATE TRIGGER order_head_state_trg
  AFTER INSERT
  ON order_head
  FOR EACH ROW
  BEGIN
insert into order_history_link SET order_id = NEW.order_id ,state_id = NEW.state;

END;

