CREATE VIEW vrest_date AS
  SELECT
    `etc`.`rest_date`.`rest_date`    AS `rest_date`,
    `etc`.`rest_date`.`rest`         AS `rest`,
    `etc`.`rest_date`.`plan_rest`    AS `plan_rest`,
    `etc`.`rest_date`.`purchase`     AS `purchase`,
    `etc`.`rest_date`.`sales`        AS `sales`,
    `etc`.`rest_date`.`product_id`   AS `product_id`,
    `etc`.`rest_date`.`warehouse_id` AS `warehouse_id`
  FROM `etc`.`rest_date`
  WHERE ((`etc`.`rest_date`.`rest` >= 0) AND (`etc`.`rest_date`.`plan_rest` >= 0));

