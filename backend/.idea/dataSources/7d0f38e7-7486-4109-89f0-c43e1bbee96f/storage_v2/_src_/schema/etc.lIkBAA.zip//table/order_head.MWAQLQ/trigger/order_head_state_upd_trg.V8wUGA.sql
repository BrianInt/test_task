CREATE TRIGGER order_head_state_upd_trg
  AFTER UPDATE
  ON order_head
  FOR EACH ROW
  BEGIN
  IF NEW.state <> OLD.state THEN
    INSERT INTO order_history_link
    SET order_id = NEW.order_id,
        state_id = NEW.state,
        oper_id = NEW.oper_id;
  END IF;

END;

