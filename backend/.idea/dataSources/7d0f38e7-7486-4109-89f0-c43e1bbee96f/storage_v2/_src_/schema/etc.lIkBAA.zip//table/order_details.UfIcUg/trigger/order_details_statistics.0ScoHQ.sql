CREATE TRIGGER order_details_statistics
  BEFORE INSERT
  ON order_details
  FOR EACH ROW
  BEGIN
  UPDATE product_statistics
     SET total_purchases = total_purchases + 1
   WHERE product_id = NEW.product;
END;

