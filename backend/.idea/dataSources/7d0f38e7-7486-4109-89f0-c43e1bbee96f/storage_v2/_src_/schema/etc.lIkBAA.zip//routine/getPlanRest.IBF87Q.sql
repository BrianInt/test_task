CREATE FUNCTION getPlanRest(p_product_id BIGINT, p_warehouse_id BIGINT, p_rest_date DATE)
  RETURNS INT
  BEGIN
    DECLARE previous_plan_rest DOUBLE;
    SELECT
      t.plan_rest into previous_plan_rest
    FROM rest_date t
    WHERE t.product_id = p_product_id
          AND t.warehouse_id = p_warehouse_id
          AND t.rest_date = (SELECT
                               MAX(tt.rest_date)
                             FROM rest_date tt
                             WHERE tt.rest_date <= p_rest_date
                                   AND tt.product_id = t.product_id);
    RETURN IFNULL(previous_plan_rest, 0);
  END;

