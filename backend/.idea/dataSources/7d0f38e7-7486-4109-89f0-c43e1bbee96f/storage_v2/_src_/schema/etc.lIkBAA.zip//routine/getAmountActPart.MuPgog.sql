CREATE FUNCTION getAmountActPart(p_product_id BIGINT, p_order_id BIGINT)
  RETURNS INT
  BEGIN
    DECLARE rest_active_part DOUBLE;
    select sum(ip.rest_amount) into rest_active_part
    from invoice_part ip
      inner join invoice i on (i.id = ip.invoice_id and i.invoice_type =0)
    where ip.product_id = p_product_id
      AND ip.active = 1;
    RETURN IFNULL(rest_active_part, -1);
  END;

