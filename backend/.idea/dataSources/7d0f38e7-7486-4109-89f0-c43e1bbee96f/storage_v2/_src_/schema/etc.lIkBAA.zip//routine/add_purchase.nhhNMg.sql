CREATE PROCEDURE add_purchase(IN p_rest_date DATE, IN p_product_id BIGINT, IN p_warehouse_id BIGINT,
                              IN p_purchase  BIGINT)
  BEGIN

  INSERT INTO vrest_date (rest_date, product_id, warehouse_id, rest, plan_rest, purchase)
    VALUES (p_rest_date, p_product_id, p_warehouse_id, etc.getPreviousRest(p_product_id, p_warehouse_id, p_rest_date) + p_purchase, etc.getPreviousPlanRest(p_product_id, p_warehouse_id, p_rest_date) + p_purchase, p_purchase)
  ON DUPLICATE KEY UPDATE rest = rest + p_purchase, plan_rest = plan_rest + p_purchase,
  purchase = purchase + p_purchase;

  UPDATE vrest_date
  SET plan_rest = plan_rest + p_purchase,
      rest = rest + p_purchase
  WHERE product_id = p_product_id
  AND warehouse_id = p_warehouse_id
  AND rest_date > p_rest_date ;

END;

